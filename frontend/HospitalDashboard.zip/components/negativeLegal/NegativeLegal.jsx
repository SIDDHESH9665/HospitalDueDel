import React from "react";

const NegativeLegal = ({ data }) => {
  const legalItems = [
    {
      label: "Blacklist Count",
      value: data?.blacklist || 0,
      color:
        data?.blacklist > 4 ? "red" : data?.blacklist >= 1 ? "orange" : "green",
      logo: "/blacklist.png",
    },
    {
      label: "Criminal Case",
      value: data?.criminal_case || "No Record Found",
      color:
        data?.criminal_case?.toLowerCase() === "recent"
          ? "red"
          : data?.criminal_case?.toLowerCase() === "old"
          ? "yellow"
          : "black",
      logo: "/case.svg",
    },
    {
      label: "Civil Case",
      value: data?.civil_case || "No Record Found",
      color:
        data?.civil_case?.toLowerCase() === "recent"
          ? "red"
          : data?.civil_case?.toLowerCase() === "old"
          ? "yellow"
          : "black",
      logo: "/case.png",
    },
    {
      label: "PMJAY Status",
      value: data?.pmjay_status || "Not Available",
      color:
        data?.pmjay_status?.toLowerCase() === "yes"
          ? "green"
          : data?.pmjay_status?.toLowerCase() === "no"
          ? "red"
          : "black",
      logo: "/pmjay.png",
    },
  ];

  return (
    <div className="negative-container">
      <h3>Negative Legal</h3>
      <div className="negative-row flex">
        {legalItems.map((item, index) => (
          <div key={index} className="negative-item">
            <img src={item.logo} alt={item.label} className="negative-logo" />
            <p>
              {item.label}:{" "}
              <span style={{ color: item.color }}>{item.value}</span>
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NegativeLegal;

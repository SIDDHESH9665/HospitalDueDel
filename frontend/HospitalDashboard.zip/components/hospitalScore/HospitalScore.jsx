import React from "react";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";

const HospitalScore = ({ score }) => {
  return (
    <div className="score-container" style={{ textAlign: "center" }}>
      <h3>Hospital Score</h3>
      <div style={{ width: 120, height: 120, margin: "auto" }}>
        <CircularProgressbar
          value={score}
          text={`${score}%`}
          styles={buildStyles({
            textSize: "16px",
            pathColor: score > 70 ? "green" : score > 40 ? "yellow" : "red",
            textColor: "#333",
            trailColor: "#ddd",
          })}
        />
      </div>
    </div>
  );
};

export default HospitalScore;
